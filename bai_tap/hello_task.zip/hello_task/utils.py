def tinh_diem_tb(scores):
    if not scores:
        return None

    return sum(scores.values()) / len(scores)


def xep_loai(diem):
    if diem is None:
        return "Chưa có điểm"

    if diem >= 8.5:
        return "Giỏi"

    elif diem >= 7.0:
        return "Khá"

    elif diem >= 5.0:
        return "Trung bình"

    else:
        return "Yếu"


def badge_class(loai):
    if loai in ["Giỏi", "Khá"]:
        return "badge-good"

    elif loai == "Trung bình":
        return "badge-medium"

    else:
        return "badge-weak"
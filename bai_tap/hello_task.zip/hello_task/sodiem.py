from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    abort,
    redirect,
    url_for,
    make_response
)

from data import STUDENTS
from utils import tinh_diem_tb, xep_loai, badge_class


app = Flask(__name__)


# =========================================================
# CÂU 1 - TRANG CHỦ
# =========================================================
@app.route("/")
def index():

    tong_sv = len(STUDENTS)

    cac_lop = {
        student["lop"]
        for student in STUDENTS.values()
    }

    tong_lop = len(cac_lop)

    return render_template(
        "index.html",
        tong_sv=tong_sv,
        tong_lop=tong_lop
    )


# =========================================================
# CÂU 2 - DANH SÁCH SINH VIÊN
# =========================================================
@app.route("/students")
def student_list():

    # Lấy tham số ?lop=...
    lop_filter = request.args.get(
        "lop",
        ""
    ).strip()

    # Lấy danh sách lớp từ dữ liệu
    # Không viết cứng K47A, K47B, K47C
    cac_lop = sorted({
        student["lop"]
        for student in STUDENTS.values()
    })

    danh_sach = []

    for mssv, student in STUDENTS.items():

        # Lọc lớp, không phân biệt hoa thường
        if lop_filter:
            if (
                student["lop"].lower()
                != lop_filter.lower()
            ):
                continue

        diem_tb = tinh_diem_tb(
            student["scores"]
        )

        loai = xep_loai(diem_tb)

        danh_sach.append({
            "mssv": mssv,
            "name": student["name"],
            "lop": student["lop"],

            "diem_tb": (
                f"{diem_tb:.2f}"
                if diem_tb is not None
                else "-"
            ),

            "xep_loai": loai,

            "badge": badge_class(loai)
        })

    return render_template(
        "students.html",
        students=danh_sach,
        cac_lop=cac_lop,
        lop_filter=lop_filter
    )


# =========================================================
# CÂU 3 - CHI TIẾT SINH VIÊN
# /students/<mssv>
# =========================================================
@app.route("/students/<mssv>")
def student_detail(mssv):

    student = STUDENTS.get(mssv)

    # MSSV không tồn tại -> 404
    if student is None:
        abort(
            404,
            description=(
                f"Không có sinh viên "
                f"với MSSV = {mssv}."
            )
        )

    diem_tb = tinh_diem_tb(
        student["scores"]
    )

    loai = xep_loai(diem_tb)

    return render_template(
        "student_detail.html",

        mssv=mssv,

        student=student,

        diem_tb=(
            f"{diem_tb:.2f}"
            if diem_tb is not None
            else "-"
        ),

        xep_loai=loai,

        badge=badge_class(loai)
    )


# =========================================================
# CÂU 4 - LINK RÚT GỌN
# /sv/<mssv>
# Chuyển sang /students/<mssv> với mã 301
# =========================================================
@app.route("/sv/<mssv>")
def student_short(mssv):

    if mssv not in STUDENTS:

        abort(
            404,
            description=(
                f"Không có sinh viên "
                f"với MSSV = {mssv}."
            )
        )

    return redirect(
        url_for(
            "student_detail",
            mssv=mssv
        ),
        code=301
    )


# =========================================================
# CÂU 5 - XUẤT BẢNG ĐIỂM CSV
# /students/<mssv>/export
# =========================================================
@app.route("/students/<mssv>/export")
def export_student(mssv):

    student = STUDENTS.get(mssv)

    if student is None:

        abort(
            404,
            description=(
                f"Không có sinh viên "
                f"với MSSV = {mssv}."
            )
        )

    # Nội dung CSV
    csv_content = "hoc_phan,diem\n"

    for hoc_phan, diem in student["scores"].items():

        csv_content += (
            f"{hoc_phan},{diem}\n"
        )

    # Tạo response
    response = make_response(
        csv_content
    )

    # Header đúng theo yêu cầu
    response.headers["Content-Type"] = (
        "text/csv; charset=utf-8"
    )

    response.headers["Content-Disposition"] = (
        f"attachment; "
        f"filename=diem_{mssv}.csv"
    )

    return response


# =========================================================
# API DANH SÁCH SINH VIÊN
# =========================================================
@app.route("/api/students")
def api_students():

    data = {}

    for mssv, student in STUDENTS.items():

        diem_tb = tinh_diem_tb(
            student["scores"]
        )

        data[mssv] = {

            "name":
                student["name"],

            "lop":
                student["lop"],

            "scores":
                student["scores"],

            "diem_trung_binh": (
                round(diem_tb, 2)
                if diem_tb is not None
                else None
            ),

            "xep_loai":
                xep_loai(diem_tb)
        }

    return jsonify(data)


# =========================================================
# TRANG 404 TÙY BIẾN
# =========================================================
@app.errorhandler(404)
def page_not_found(error):

    return render_template(
        "404.html",
        message=error.description
    ), 404


# =========================================================
# CHẠY ỨNG DỤNG
# =========================================================
if __name__ == "__main__":

    app.run(
        debug=True,
        port=8000
    )